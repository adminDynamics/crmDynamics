import { createClient } from "@supabase/supabase-js"

const supabaseUrl = "https://qxsrtcojpttaweymaxcw.supabase.co"
const supabaseKey =
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ||
  process.env.SUPABASE_SERVICE_ROLE_KEY ||
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InF4c3J0Y29qcHR0YXdleW1heGN3Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc0ODM2NzI1NiwiZXhwIjoyMDYzOTQzMjU2fQ.BBqVN_lMnPsroQ-swVz6NjkaYo7lTlW0IQGfyL1_9lA"

export const supabase = createClient(supabaseUrl, supabaseKey)

export interface SupabaseMessage {
  id: string
  message: string // Cambiar de "mensaje" a "message"
  tipo: "cliente" | "bot"
  user_id: string
  conversation_id: string
  chat_id: string
  timestamp: string
  created_at?: string // Opcional ya que no está en la tabla
}

export async function loadHistoricalMessages(): Promise<SupabaseMessage[]> {
  try {
    console.log("🔄 Cargando mensajes históricos desde Supabase...")

    const { data, error } = await supabase
      .from("messages")
      .select("id, conversation_id, message, timestamp, tipo, user_id, chat_id")
      .order("timestamp", { ascending: true })

    if (error) {
      console.error("❌ Error cargando mensajes históricos:", error)
      return []
    }

    console.log(`✅ Cargados ${data?.length || 0} mensajes históricos`)
    return data || []
  } catch (error) {
    console.error("❌ Error conectando con Supabase:", error)
    return []
  }
}

export async function saveMessage(message: {
  id: string
  mensaje: string // Recibe "mensaje" del código interno
  tipo: "cliente" | "bot"
  user_id: string
  conversation_id: string
  chat_id?: string
  timestamp: string
}): Promise<boolean> {
  try {
    const { error } = await supabase.from("messages").insert([
      {
        id: message.id,
        message: message.mensaje, // Mapear "mensaje" a "message" para la DB
        tipo: message.tipo,
        user_id: message.user_id,
        conversation_id: message.conversation_id,
        chat_id: message.chat_id,
        timestamp: message.timestamp,
      },
    ])

    if (error) {
      console.error("❌ Error guardando mensaje:", error)
      return false
    }

    return true
  } catch (error) {
    console.error("❌ Error guardando en Supabase:", error)
    return false
  }
}
