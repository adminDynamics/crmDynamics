"use client"

import { useState } from "react"
import { Sidebar } from "@/components/sidebar"
import { ConversationsList } from "@/components/conversations-list"
import { ChatPanel } from "@/components/chat-panel"
import { useSocket } from "@/hooks/use-socket"

export default function CRMPage() {
  const [selectedConversation, setSelectedConversation] = useState<string | null>(null)
  const { isConnected, connectionError } = useSocket()

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Connection Status */}
      {!isConnected && (
        <div className="absolute top-0 left-0 right-0 bg-red-500 text-white text-center py-2 text-sm z-50">
          {connectionError ? `Error: ${connectionError}` : "Conectando..."}
        </div>
      )}

      <div className={`flex w-full ${!isConnected ? "mt-10" : ""}`}>
        <Sidebar />
        <ConversationsList selectedConversation={selectedConversation} onSelectConversation={setSelectedConversation} />
        <ChatPanel conversationId={selectedConversation} onBack={() => setSelectedConversation(null)} />
      </div>
    </div>
  )
}
